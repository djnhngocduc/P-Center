# SMAC

SMAC is a tool to automatically tune a tool with respect to a given benchmark.
For Riss, this benchmark is a set of CNFs. The files in this directory show
case how an example setup with Riss might look like.

# Running

When running the file smac.sh from this directory, the scenario files is used
to drive the search of SMAC for a short period of time. The files present only
an example without any modifications for properly configuring Riss with a
reasonable amount of resources on a given target benchmark.
